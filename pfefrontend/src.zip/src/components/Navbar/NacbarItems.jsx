const navbarItems = [
    {
        title: "About",
        link: "/about",
    },
    {
        title: "Services",
        link: "/Services",
    },
];

export default navbarItems;